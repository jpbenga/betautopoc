---
name: BetAuto Analytical Interface
colors:
  surface: '#12131a'
  surface-dim: '#12131a'
  surface-bright: '#383941'
  surface-container-lowest: '#0d0e15'
  surface-container-low: '#1a1b22'
  surface-container: '#1e1f26'
  surface-container-high: '#292931'
  surface-container-highest: '#33343c'
  on-surface: '#e3e1ec'
  on-surface-variant: '#bcc9cd'
  inverse-surface: '#e3e1ec'
  inverse-on-surface: '#2f3038'
  outline: '#869397'
  outline-variant: '#3d494c'
  surface-tint: '#4cd7f6'
  primary: '#4cd7f6'
  on-primary: '#003640'
  primary-container: '#06b6d4'
  on-primary-container: '#00424f'
  inverse-primary: '#00687a'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb873'
  on-tertiary: '#4b2800'
  tertiary-container: '#e89337'
  on-tertiary-container: '#5b3200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#acedff'
  primary-fixed-dim: '#4cd7f6'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdcbf'
  tertiary-fixed-dim: '#ffb873'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6a3b00'
  background: '#12131a'
  on-background: '#e3e1ec'
  surface-variant: '#33343c'
typography:
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-main:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-caps:
    fontFamily: Work Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-data:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin: 24px
---

## Brand & Style
The brand personality is rooted in high-fidelity precision and serious financial utility. It avoids the typical "gaming" aesthetic in favor of a sophisticated, high-control SaaS environment. The target audience consists of professional traders and data analysts who require a "heads-up display" (HUD) that minimizes cognitive load while providing deep insights.

The design style is **Minimalist with Glassmorphic accents**. It utilizes a "Vercel-esque" clarity combined with the density of Datadog. The emotional response is one of total reliability and cold, calculated efficiency. Visual cues emphasize the "AI" aspect through subtle glowing elements and crisp, thin lines rather than decorative illustrations.

## Colors
The palette is centered on a "Deep Night" foundation to reduce eye strain during long analytical sessions. 

- **Foundation:** The deepest layer (#09090b) is reserved for the primary canvas, while the elevated surface (#18181b) is used for cards and navigation panels.
- **Accents:** Electric Cyan (#06b6d4) serves as the primary action color. Emerald (#10b981) is strictly reserved for positive financial deltas and active "On" states. Amber (#f59e0b) provides high-contrast visibility for risk warnings.
- **Borders:** Subtle Grey (#27272a) is the workhorse for structural separation, ensuring the UI remains crisp without feeling boxed in.

## Typography
This design system utilizes **Inter** for its neutral, functional performance in dense interfaces. To maintain an analytical feel, **Space Grotesk** is used for technical data, logs, and financial numerals, providing a "high-tech" geometric flair that distinguishes data from UI labels.

- **Headlines:** Keep tight letter spacing and medium weights to maintain a compact, professional look.
- **Labels:** Use Work Sans in uppercase for secondary section headers to provide a clear hierarchy without increasing size.
- **Data Tables:** Always use the Monospace variant for numeric values to ensure columnar alignment of decimals.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. Navigation and sidebars are fixed-width (240px and 64px respectively), while the central dashboard utilizes a fluid 12-column grid.

- **Rhythm:** A 4px baseline grid ensures tight vertical rhythm. 
- **Density:** High-density spacing is preferred. Gutters should remain at 16px to maximize data real estate while maintaining enough "air" to prevent visual clutter.
- **Alignment:** All elements must align to the grid edges. Padding inside cards should be a consistent 16px (md) to 24px (lg) depending on the complexity of the data visualized.

## Elevation & Depth
Depth is created through **Tonal Layering** and **Low-Contrast Outlines** rather than heavy drop shadows.

- **The Stack:** The background layer is #09090b. Cards sit atop this at #18181b. Modals and popovers sit at #27272a with a very subtle, 20% opacity cyan glow if they are AI-driven.
- **Glassmorphism:** Use a 12px backdrop-blur on sticky headers and navigation sidebars with a 40% opacity fill of the background color.
- **Borders:** Every container must have a 1px solid border (#27272a). For active states, the border transitions to the primary cyan color.

## Shapes
The design system employs a **Rounded** aesthetic with specific logic for different scales. 

- **Cards:** Fixed at 12px to soften the technical layout and provide a premium, modern SaaS feel.
- **Interactive Elements:** Buttons and inputs use a smaller 6px radius to maintain a sense of "precision tools" rather than "playful widgets."
- **Status Indicators:** Icons and status pips use a circular (pill) shape to distinguish them from structural elements.

## Components
- **Buttons:** Primary buttons are solid Cyan with black text. Secondary buttons are Ghost-style with a #27272a border and white text. Use a subtle linear gradient (top-to-bottom, 5% opacity white) to give a tactile feel.
- **Cards:** 12px rounded corners, #18181b background, and a 1px #27272a border. Headers within cards should have a bottom border to separate controls from data.
- **Data Tables:** No vertical borders. Horizontal borders only (#27272a). Row hover states should use a subtle #27272a background fill.
- **Glowing Status Indicators:** 8px circles with a 4px outer glow (box-shadow) using the status color (Emerald for active, Amber for warning, Slate for idle).
- **Financial Charts:** Area charts should use a Cyan stroke with a fading Cyan-to-transparent gradient fill. Grid lines must be the same color as borders (#27272a) but at 50% opacity.
- **Inputs:** Dark background (#09090b), 1px border. Focus state triggers a 1px Cyan border and a 0px 0px 0px 2px rgba(6, 182, 212, 0.2) outer ring.